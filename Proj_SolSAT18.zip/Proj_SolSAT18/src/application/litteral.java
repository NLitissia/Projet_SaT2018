package application;


import java.util.ArrayList;
import java.util.LinkedList;
public class litteral {
int value;
int depth;
litteral parent;
int Satclause;
int vist ;
int fopen;
LinkedList<litteral> successors = new LinkedList<>();
int Hval;
litteral(){}

litteral(int v,int d,litteral p,int s,int vist,int fopen,int h)
{
this.value=v;
this.depth=d;
this.parent=p;
this.vist=vist;
this.Satclause=s;
this.fopen = fopen;
this.Hval=h;
}

LinkedList<litteral> getlistsucc()
{
return 	this.successors;
}

void setlistsucc(LinkedList<litteral> s)
{
   this.successors=s;
}
}
