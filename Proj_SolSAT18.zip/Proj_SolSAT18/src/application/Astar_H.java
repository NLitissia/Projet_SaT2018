package application;


	import java.io.File;
	import java.io.FileNotFoundException;
	import java.util.ArrayList;
	import java.util.Comparator;
	import java.util.HashSet;
	import java.util.LinkedList;
	import java.util.List;
	import java.util.Random;
	import java.util.Scanner;
	import java.util.Vector;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

	public class Astar_H {
		/**************************** attributs ********************************/
		litteral clauses[][]; // litteral clauses [nbclauses][3]
		int nbvars, nbclauses;
		LinkedList<litteral> open;
		LinkedList<litteral> close;
		ArrayList<litteral> chaiArr;

		/**************************** constructeur ********************************/
		Astar_H(int n, int m) {
			this.nbvars = n;
			this.nbclauses = m;
			this.clauses = new litteral[nbclauses][3];
			open = new LinkedList<litteral>();
			close = new LinkedList<litteral>();
			chaiArr = new ArrayList<litteral>();
		}

		/**************************** m�thodes
		 * @throws FileNotFoundException ********************************/
		void remplir_matrice_clause(String fich) throws FileNotFoundException {
		//	File file = new File("D:/Etudes/M1 SII 2017_2018/S2/M�ta-heuristique/Projet_TP/Code/uf75-325/ai/hoos/Shortcuts/UF75.325.100/uf75-06.cnf"); 
			if(fich == null)
			{		System.out.println("Choisir un fichier");
			   }
			else{
				File file= new File("/application/"+fich);
			Scanner stdin = new Scanner(file);
			int u = 0;
			String s = null;
			while (u < 8) //sauter les lignes jusqu'a p cnf nbvar nbclauses
			{
				s = stdin.nextLine();
				//  System.out.println(s);
				u++;
			}

			litteral node = null;
			int xi;
			for (int i = 0; i < this.nbclauses; i++)
				for (int j = 0; j < 3; j++) {
					xi = stdin.nextInt();
					if (xi == 0) {
						xi = stdin.nextInt();
					}
				 /*   if (xi < 0)
						node = new litteral(xi, 0, null, 0);
					else if (xi > 0)
						*/node = new litteral(xi, 0, null, 0,0,0,0);

					this.clauses[i][j] = node;
					//System.out.println("clause"+i+"/"+j+"="+this.clauses[i][j].cle);

				}
			}

		}


	 
		/**************************** ********************************/
		boolean trouve_close(LinkedList<litteral> close, litteral node) {
			for (int i = 0; i < close.size(); i++) {

				if (close.get(i).value == node.value )
					return true;
			}

			return false;
		}

		/**************************** ********************************/
		private int fonction_objectif(litteral node) {
			int som = 0;
			for (int i = 0; i < this.nbclauses; i++)
				for (int j = 0; j < 3; j++) {
					if (clauses[i][j] != null && node.parent != null)
						if (clauses[i][j].value == node.value) //no need to test val 0 ou 1 cause clauses[][] contient les vars sous forme xi /-xi
						{
							som = som + 1;
						}


				}
			System.out.println(" sum= "+som);
			node.Satclause = som;
			return node.Satclause;
		}

		/***************************** ******************************/
		   private int fonction_evaluation(litteral node)
			{   
				litteral x;
			    int som=0;
			    HashSet<litteral> instance_sol = new HashSet<litteral>();
				//ArrayList<Integer> instance_sol =new ArrayList<Integer>();
				
				instance_sol=instance_solution_sat(node);

				int sat_clause;
				int i,k=0;
				i=0; 
				while(i < this.nbclauses)
				{  
					for (litteral j : instance_sol) 
					{     
						k=0; sat_clause=0;
						while(k<3 && sat_clause==0)
						{
							
						if((clauses[i][k].value == j.value))
						{	 
							if(j.vist != -1){
							sat_clause=1; 
						    som++;
						    j.vist= -1;    
						}
						sat_clause=1; 
					   }
						
						else k++;
						
						}//fin while3
						j.vist=0;
						if(sat_clause == 1)
							break;
					}//fin for	
					 i++; 
				}//fin while1
					
					node.Satclause=som;
				return node.Satclause;	
				
			}

		/***************************** ******************************/
			private ArrayList<litteral> retracer_chemin(litteral node) {

				//this.chaiArr.add(node);
				ArrayList<litteral> pred=new ArrayList<litteral>();
				while(node.value != 0 && node.parent != null)
				{
					pred.add(node.parent);
					node=node.parent;
					//System.out.println("chAr"+node.value);
				}
				return pred;
			}


		 /***************************** ******************************/
			private HashSet<litteral> instance_solution_sat(litteral node) {
				HashSet<litteral> V=new HashSet<litteral>();
				V.add(node);
				while(node.value != 0 && node.parent != null)
				{
					V.add(node.parent);
					node=node.parent;
					//System.out.println("chAr"+node.value);
				}
				return V;
			}
			 /***************************** ******************************/
			
			void open_a_star(litteral x)
			{ 
				this.open.addLast(x);
				this.open.sort(new Comparator<litteral>(){
					 public int compare(litteral o1, litteral o2){
						 if(o1.Hval == o2.Hval)
							 return 0;
						 return o1.Hval < o2.Hval ? -1 : 1;
					 }
				});
				/*System.out.print(" open apres insertion \n");
				for(int k=0;k<this.open.size();k++)
				{  
					System.out.println("valeur "+this.open.get(k).value+" NBS "+this.open.get(k).fopen+"\t");
				}*/
			}
			/***************************** ******************************/
	 private int fonction_classOpen(litteral node)
			{   
		  	if(node.fopen == 0) {
				int trouve=0, i,som=0;
				i=0; 
				while(i < this.nbclauses)
				{  
				  int j =0; 
				  trouve=0;
				  while((j<3)&& trouve==0)
				  {
					 if(this.clauses[i][j].value==node.value) 
					 {
						 trouve = 1;
						som++;
					 }
					 
					 j++;
				  }
					
					i++;
				}//fin while1
				
				node.fopen = som;	
			}
				return node.fopen;	
				
			}
	 /***********************************************************************/
		int fonction_contains(litteral Trandom,litteral cur)
		{
			int i=0;
			if(Trandom.value == 0) return -1;
			if(cur.value == Trandom.value || cur.value == -(Trandom.value)) return -1;
			if(cur.depth == this.nbvars ) return 0;
			 ArrayList<litteral> pred= retracer_chemin(Trandom);
			while(i< pred.size())
			{ if( pred.get(i).value == Trandom.value || pred.get(i).value == -(Trandom.value)  )
				return -1;
			 i++;
			}
			 
			return 0;
		}
 
		/***************************** ******************************/
		@FXML
		private Label myMsg;
		int Parcours(int temps) {
	        litteral valneg, valpos, node = null;
	        int  clsatis = 0; int tempMax = temps;//680;
	        LinkedList<litteral> successors;
	        int max =0;int num=0,existe=0;
	        litteral root = new litteral(0, 0, null, 0,0,0,0); //nos littraux start from 1
	        open.add(root);
	        litteral Trandom;
	        Random rand = new Random();
	       
	       double Ctime = System.currentTimeMillis()/1000;
	        while (!open.isEmpty() )
	        {
	        
	            litteral cur = open.removeFirst();//pr DFS open.removeLast();
	            close.add(cur);
	           // System.out.println("profondeur= "+cur.depth);
	            clsatis = fonction_evaluation(cur);
	            if(max < clsatis)
	            {
	            	max=clsatis;
	            }
	           // System.out.println("max= " +max);
	           
	            if (clsatis == this.nbclauses) // to test nbr de clauses satisfaites
	            {
	             //   System.out.println("Gonna break,SAT !!! ");
	            return clsatis;
	            	 //on a fini la recherche, espace satisfiable
	            }
	            
	           // System.out.println("depth=  "+cur.depth+" sum= "+clsatis);
	            if (cur.depth == 19) {
	                continue;  //saute itération pr enlever de close sans ajouter dans open to gain time
	            }
	           
	            num = (int) ((int)(this.nbvars)*Math.random());
	            Trandom = new litteral(num,cur.depth+1, cur, 0,0,0,0);
	            
	            //System.out.println("randomm first "+num);
	            existe = 0;
	             
	            
	            	while( fonction_contains(Trandom,cur) == -1  )
	            	{	
	            	
	            		num = (int) ((int)(this.nbvars+1)*Math.random());
	            		Trandom = new litteral(num,cur.depth+1, cur, 0,0,0,0);
	            		//System.out.println("randomm while "+num);
	          		
	            	}
	            
	            	 
	             
	            valneg = new litteral(-(num), cur.depth+1, cur, 0,0,0,0); //node c'est le parent
	            valpos = new litteral(num,cur.depth+1, cur, 0,0,0,0);
	           
	            successors= cur.getlistsucc();
	            successors.add(valneg);
	            successors.add(valpos);
	            cur.setlistsucc(successors);
	            for (litteral successor : successors) {
	                if(!close.contains(successor))
	                {  
	                    open.addLast(successor);
	                }
	            }
	           
	        /*    for(int k =0;k<open.size();k++)
	            {
	            	System.out.print(open.get(k).value+"\t");
	            	
	            }
	          */  
	            
	            if(System.currentTimeMillis()/1000 -Ctime > tempMax){
	            	break;
	            }
	        } //fin while
	        
	        
	         //System.out.println("Max SAT: "+max);
	        // System.out.println("CLOSE : "+close.size());
	         return max;
			} //fin parcours
	    

		
	//        if (open.isEmpty())
	//
	//        {
	//            System.out.println(close.size());
	//            System.out.println("Non satisfiable");
	//        }
	//        if (node != null)
	//
	//            retracer_chemin(this.close, node);

		} // fin classe 


	//} //fin classe