package application;


import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class SAT_DFS {
    /**************************** attributs ********************************/
    litteral clauses[][]; // litteral clauses [nbclauses][3]
    int nbvars, nbclauses;
    LinkedList<litteral> open;
    Vector<Integer> choixvars;
    LinkedList<litteral> close;
    ArrayList<litteral> chaiArr;

    /**************************** constructeur ********************************/
    SAT_DFS(int n, int m) {
        this.nbvars = n;
        this.nbclauses = m;
        this.clauses = new litteral[nbclauses][3];
        open = new LinkedList<litteral>();
        choixvars = new Vector<Integer>(75);
        close = new LinkedList<litteral>();
        chaiArr = new ArrayList<litteral>();
    }

    /**************************** m�thodes
     * @throws FileNotFoundException ********************************/
	void remplir_matrice_clause(String fich) throws FileNotFoundException {
	//	File file = new File("D:/Etudes/M1 SII 2017_2018/S2/M�ta-heuristique/Projet_TP/Code/uf75-325/ai/hoos/Shortcuts/UF75.325.100/uf75-06.cnf"); 
		if(fich == null)
		{		System.out.println("Choisir un fichier");
		   }
		else{
			File file= new File("/application/"+fich);
		Scanner stdin = new Scanner(file);
		int u = 0;
		String s = null;
		while (u < 8) //sauter les lignes jusqu'a p cnf nbvar nbclauses
		{
			s = stdin.nextLine();
			//  System.out.println(s);
			u++;
		}

		litteral node = null;
		int xi;
		for (int i = 0; i < this.nbclauses; i++)
			for (int j = 0; j < 3; j++) {
				xi = stdin.nextInt();
				if (xi == 0) {
					xi = stdin.nextInt();
				}
			 /*   if (xi < 0)
					node = new litteral(xi, 0, null, 0);
				else if (xi > 0)
					*/node = new litteral(xi, 0, null, 0,0,0,0);

				this.clauses[i][j] = node;
				//System.out.println("clause"+i+"/"+j+"="+this.clauses[i][j].cle);

			}
		}

	}


    /******************************************************************/
    void construire_chemin(Vector<Integer> choixvars) {
        Random rand = new Random();
        int num;

        for (int i = 0; i < this.nbvars; i++) {
            num = rand.nextInt(this.nbvars);
            choixvars.addElement(i);
            //	System.out.println("x "+choixvars.get(i));
        }
    }

    /**************************** ********************************/
    boolean trouve_close(LinkedList<litteral> close, litteral node) {
        for (int i = 0; i < close.size(); i++) {

            if (close.get(i).value == node.value )
                return true;
        }

        return false;
    }

    /**************************** ********************************/
    private int fonction_objectif(litteral node) {
        int som = 0;
        for (int i = 0; i < this.nbclauses; i++)
            for (int j = 0; j < 3; j++) {
                if (clauses[i][j] != null && node.parent != null)
                    if (clauses[i][j].value == node.value) //no need to test val 0 ou 1 cause clauses[][] contient les vars sous forme xi /-xi
                    {
                        som = som + 1;
                    }


            }
        System.out.println(" sum= "+som);
        node.Satclause = som;
        return node.Satclause;
    }
    /****************************************************************/
	private HashSet<litteral> instance_solution_sat(litteral node) {
		HashSet<litteral> V=new HashSet<litteral>();
		V.add(node);
		while(node.value != 0 && node.parent != null)
		{
			V.add(node.parent);
			node=node.parent;
			//System.out.println("chAr"+node.value);
		}
		return V;
	}

    /***************************** ******************************/
    private int fonction_evaluation(litteral node)
 			{   
 				litteral x;
 			    int som=0;
 			    HashSet<litteral> instance_sol = new HashSet<litteral>();
 				//ArrayList<Integer> instance_sol =new ArrayList<Integer>();
 				
 				instance_sol=instance_solution_sat(node);

 				int sat_clause;
 				int i,k=0;
 				i=0; 
 				while(i < this.nbclauses)
 				{  
 					for (litteral j : instance_sol) 
 					{     
 						k=0; sat_clause=0;
 						while(k<3 && sat_clause==0)
 						{
 							
 						if((clauses[i][k].value == j.value))
 						{	 
 							if(j.vist != -1){
 							sat_clause=1; 
 						    som++;
 						    j.vist= -1;    
 						}
 						sat_clause=1; 
 					   }
 						
 						else k++;
 						
 						}//fin while3
 						j.vist=0;
 						if(sat_clause == 1)
 							break;
 					}//fin for	
 					 i++; 
 				}//fin while1
 					
 					node.Satclause=som;
 				return node.Satclause;	
 				
 			}

    /*    private int fonction_evaluation(litteral node)
	{   
		litteral x;
	    int som=0,j=0;
		ArrayList<Integer> instance_sol =new ArrayList<Integer>();
		
		instance_sol=instance_solution_sat(node);

		int sat_clause;
		int i,k=0;
		i=0; 
		while(i < this.nbclauses)
		{
			j=0;  
			while(  j< instance_sol.size())
			{   
				k=0; sat_clause=0;
				while(k<3 && sat_clause==0)
				{
				if(clauses[i][k].value == instance_sol.get(j))
				{	sat_clause=1; som++;
				}
				else k++;
				}//fin while3
				
				j++;
			}//fin while2	
				/*if(sat_clause) i++; used quand on veut confirmer si c'est une sol ou pas
				else satisf=false; mais nous on cherche � compter donc on continue d'avancer*/  
		//	 i++; 
	/*	}//fin while1
			
			node.Satclause=som;
		return node.Satclause;	
		
	}
*/
    /***************************** ******************************/
	private ArrayList<litteral> retracer_chemin(litteral node) {

		//this.chaiArr.add(node);
		ArrayList<litteral> pred=new ArrayList<litteral>();
		while(node.value != 0 && node.parent != null)
		{
			pred.add(node.parent);
			node=node.parent;
			//System.out.println("chAr"+node.value);
		}
		return pred;
	}

	/*****************************************************************/
	/*	int fonction_contains(int num,int pcur)
		{ int i=0;
		    if(num == 0) return -1;
			while(! this.open.isEmpty() && i<this.open.size())
			{
				if(pcur != this.nbvars &&(this.open.get(i).value == num || this.open.get(i).value == -num))
					return -1;
				else i++;
			}
			i=0;
			while(! this.close.isEmpty()  && i<this.close.size())
			{
				if(pcur != this.nbvars &&(this.close.get(i).value == num || this.close.get(i).value == -num))
					return -1;
				else i++;
			}
			
			return 0;
			
		}
	*/
		/**************************************************/
		int fonction_contains(litteral Trandom,litteral cur)
		{
			int i=0;
			if(Trandom.value == 0) return -1;
			if(cur.value == Trandom.value || cur.value == -(Trandom.value)) return -1;
			if(cur.depth == this.nbvars ) return 0;
			 ArrayList<litteral> pred= retracer_chemin(Trandom);
			while(i< pred.size())
			{ if( pred.get(i).value == Trandom.value || pred.get(i).value == -(Trandom.value)  )
				return -1;
			 i++;
			}
			 
			return 0;
		}
    /***************************** ******************************/
		int Parcours(int temps) {
	        litteral valneg, valpos, node = null;
	        int  clsatis = 0; int tempMax = temps;//680;
	        LinkedList<litteral> successors;
	        int max =0;int num=0,existe=0;
	        litteral root = new litteral(0, 0, null, 0,0,0,0); //nos littraux start from 1
	        open.add(root);
	        litteral Trandom;
	        Random rand = new Random();
	       
	       double Ctime = System.currentTimeMillis()/1000;
	        while (!open.isEmpty() )
	        {
	        
	            litteral cur = open.removeFirst();//pr DFS open.removeLast();
	            close.add(cur);
	           // System.out.println("profondeur= "+cur.depth);
	            clsatis = fonction_evaluation(cur);
	            if(max < clsatis)
	            {
	            	max=clsatis;
	            }
	           // System.out.println("max= " +max);
	           
	            if (clsatis == this.nbclauses) // to test nbr de clauses satisfaites
	            {
	             //   System.out.println("Gonna break,SAT !!! ");
	            return clsatis;
	            	 //on a fini la recherche, espace satisfiable
	            }
	            
	           // System.out.println("depth=  "+cur.depth+" sum= "+clsatis);
	            if (cur.depth == 19) {
	                continue;  //saute itération pr enlever de close sans ajouter dans open to gain time
	            }
	           
	            num = (int) ((int)(this.nbvars)*Math.random());
	            Trandom = new litteral(num,cur.depth+1, cur, 0,0,0,0);
	            
	            //System.out.println("randomm first "+num);
	            existe = 0;
	             
	            
	            	while( fonction_contains(Trandom,cur) == -1  )
	            	{	
	            	
	            		num = (int) ((int)(this.nbvars+1)*Math.random());
	            		Trandom = new litteral(num,cur.depth+1, cur, 0,0,0,0);
	            		//System.out.println("randomm while "+num);
	          		
	            	}
	            
	            	 
	             
	            valneg = new litteral(-(num), cur.depth+1, cur, 0,0,0,0); //node c'est le parent
	            valpos = new litteral(num,cur.depth+1, cur, 0,0,0,0);
	           
	            successors= cur.getlistsucc();
	            successors.add(valneg);
	            successors.add(valpos);
	            cur.setlistsucc(successors);
	            for (litteral successor : successors) {
	                if(!close.contains(successor))
	                {  
	                    open.addLast(successor);
	                }
	            }
	           
	        /*    for(int k =0;k<open.size();k++)
	            {
	            	System.out.print(open.get(k).value+"\t");
	            	
	            }
	          */  
	            
	            if(System.currentTimeMillis()/1000 -Ctime > tempMax){
	            	break;
	            }
	        } //fin while
	        
	        
	         //System.out.println("Max SAT: "+max);
	        // System.out.println("CLOSE : "+close.size());
	         return max;
			} //fin parcours
	    

 
    } // fin classe 


//} //fin classe
/*****************************************************************************************/
/*import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class SAT_BFS {
    /**************************** attributs ********************************/
/*    litteral clauses[][]; // litteral clauses [nbclauses][3]
    int nbvars, nbclauses;
    LinkedList<litteral> open;
    LinkedList<litteral> close;
    ArrayList<litteral> chaiArr;

    /**************************** constructeur ********************************/
/*    SAT_BFS(int n, int m) {
        this.nbvars = n;
        this.nbclauses = m;
        this.clauses = new litteral[nbclauses][3];
        open = new LinkedList<litteral>();
        close = new LinkedList<litteral>();
        chaiArr = new ArrayList<litteral>();
    }

    /**************************** m�thodes
     * @throws FileNotFoundException ********************************/
/*    void remplir_matrice_clause() throws FileNotFoundException {
		 File file = new File("D:/Etudes/M1 SII 2017_2018/S2/M�ta-heuristique/Projet_TP/Code/uf75-325/ai/hoos/Shortcuts/UF75.325.100/uf75-01.cnf"); 
        Scanner stdin = new Scanner(file);
        int u = 0;
        String s = null;
        while (u < 8) //sauter les lignes jusqu'a p cnf nbvar nbclauses
        {
            s = stdin.nextLine();
            //  System.out.println(s);
            u++;
        }

        litteral node = null;
        int xi;
        for (int i = 0; i < this.nbclauses; i++)
            for (int j = 0; j < 3; j++) {
                xi = stdin.nextInt();
                if (xi == 0) {
                    xi = stdin.nextInt();
                }
             /*   if (xi < 0)
                    node = new litteral(xi, 0, null, 0);
                else if (xi > 0)
                    */
         /*node = new litteral(xi, 0, null, 0,0,0,0);

                this.clauses[i][j] = node;
                //System.out.println("clause"+i+"/"+j+"="+this.clauses[i][j].cle);

            }


    }

 
    /**************************** ********************************/
/*    boolean trouve_close(LinkedList<litteral> close, litteral node) {
        for (int i = 0; i < close.size(); i++) {

            if (close.get(i).value == node.value )
                return true;
        }

        return false;
    }

    /**************************** ********************************/
/*    private int fonction_objectif(litteral node) {
        int som = 0;
        for (int i = 0; i < this.nbclauses; i++)
            for (int j = 0; j < 3; j++) {
                if (clauses[i][j] != null && node.parent != null)
                    if (clauses[i][j].value == node.value) //no need to test val 0 ou 1 cause clauses[][] contient les vars sous forme xi /-xi
                    {
                        som = som + 1;
                    }


            }
        System.out.println(" sum= "+som);
        node.Satclause = som;
        return node.Satclause;
    }

    /***************************** ******************************/
/*    private int fonction_evaluation(litteral node)
	{   
		litteral x;
	    int som=0;
	    HashSet<litteral> instance_sol = new HashSet<litteral>();
		//ArrayList<Integer> instance_sol =new ArrayList<Integer>();
		
		instance_sol=instance_solution_sat(node);

		int sat_clause;
		int i,k=0;
		i=0; 
		while(i < this.nbclauses)
		{  
			for (litteral j : instance_sol) 
			{     
				k=0; sat_clause=0;
				while(k<3 && sat_clause==0)
				{
					
				if((clauses[i][k].value == j.value))
				{	 
					if(j.vist != -1){
					sat_clause=1; 
				    som++;
				    j.vist= -1;    
				}
				sat_clause=1; 
			}
				
				else k++;
				
				}//fin while3
				j.vist=0;
				if(sat_clause == 1)
					break;
			}//fin for	
			 i++; 
		}//fin while1
			
			node.Satclause=som;
		return node.Satclause;	
		
	}

    /***************************** ******************************/
/*	private ArrayList<litteral> retracer_chemin(litteral node) {

		this.chaiArr.add(node);
		while(node.value != 0 && node.parent != null)
		{
			this.chaiArr.add(node.parent);
			node=node.parent;
			//System.out.println("chAr"+node.value);
		}
		return this.chaiArr;
	}

	 /***************************** ******************************/
/*		private HashSet<litteral> instance_solution_sat(litteral node) {
			HashSet<litteral> V=new HashSet<litteral>();
			V.add(node);
			while(node.value != 0 && node.parent != null)
			{
				V.add(node.parent);
				node=node.parent;
				//System.out.println("chAr"+node.value);
			}
			return V;
		}
	
    /***************************** ******************************/

 /*   void Parcours() {
    	int tempsMax=700; //12mn= 675
        litteral valneg, valpos, node = null;
        int  clsatis = 0;
        LinkedList<litteral> successors;
     
        litteral root = new litteral(0, 0, null, 0,0,0,0); //nos littraux start from 1
        open.add(root);
        
        double currTime = System.currentTimeMillis() / 1000;
        while (!open.isEmpty() )
        {

            litteral cur = open.removeFirst();//pr DFS open.removeLast();
            clsatis = fonction_evaluation(cur);
            System.out.println("prof = " +cur.depth +" nbsatisfiable = " +clsatis);
            if (clsatis == this.nbclauses) // to test nbr de clauses satisfaites
            {
                System.out.println("Gonna break,SAT !!! ");
                break; //on a fini la recherche, espace satisfiable
            }
            
          //  System.out.println("depth=  "+cur.depth+" sum= "+clsatis);
            if (cur.depth == 75 )
            {
                continue;  //saute it�ration pr enlever de close sans ajouter dans open to gain time
            }
            
            valneg = new litteral(-(cur.depth+1), cur.depth+1, cur, 0,0,0,0); //node c'est le parent
            valpos = new litteral(cur.depth+1,cur.depth+1, cur, 0,0,0,0);
            
            successors= cur.getlistsucc();
            successors.add(valneg);
            //System.out.println("open = : "+valneg.value);
            successors.add(valpos);
            //System.out.println("open1 = : "+valpos.value);
            cur.setlistsucc(successors);
            for (litteral successor : successors) {
                if(!close.contains(successor))
                {  
                    open.addLast(successor);
                }
            }
            close.add(cur);
            
            if( (System.currentTimeMillis() / 1000) - currTime > tempsMax )
            {
             System.out.println("Fin de la p�riode de tests ! ");
             break;
            }
            
        } //fin while
        
        
        
        System.out.println("CLOSE : "+close.size());
       } //fin parcours
    
//        if (open.isEmpty())
//
//        {
//            System.out.println(close.size());
//            System.out.println("Non satisfiable");
//        }
//        if (node != null)
//
//            retracer_chemin(this.close, node);
*/
  //  } // fin classe 


//} //fin classe